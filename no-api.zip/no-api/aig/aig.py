#import libraries
import os
from datetime import datetime
import pandas as pd
import re
from tqdm import tqdm
import warnings
warnings.simplefilter("ignore", UserWarning)
import tempfile

import camelot
import PyPDF2
from azure.storage.blob import BlobServiceClient

#to display pandas dataframe on max col width
connect_str = 'DefaultEndpointsProtocol=https;AccountName=storageaccountrkh;AccountKey=/sLzibq+T90hF1+KNi4oR7kYWyk338HjIug69dKfgM6NFDeCkZpMzO4LsX5wvO5xjSbpBz6Nfc98XSTjqrcMMw==;EndpointSuffix=core.windows.net'
blob_service_client = BlobServiceClient.from_connection_string(connect_str)
container_name = "pdf"
tempFilePath = tempfile.gettempdir()
downloads_path = os.path.join(tempFilePath, 'downloads')
if not os.path.exists(downloads_path):
    os.makedirs(downloads_path)
    
def return_file(file_name):
    pd.set_option('display.max_colwidth', 0)
    date_format = "%m/%d/%Y"

    #defining filename
    # file_name = 'AIG Intellirisk Basic - Champion National Security Lossrun vao 2021-12-31.pdf'

    # Reading the pdf file by PyPDF2
    reader = PyPDF2.PdfFileReader(file_name)
    #to get number of pages in pdf
    num_pages = reader.getNumPages()

    #function to divide list into small chunks of list based of n values, here n = 3
    def divide_chunks(l, n):
        for i in range(0, len(l), n): 
                yield l[i:i + n]


    result = {}
    #getting text from first page of pdf using pypdf2
    firstpage = reader.getPage(0).extractText()

    #checking if the document is in valid form with keyword = AIG LOSS RUN
    if re.search("AIG\s*Loss\s*Run",firstpage):
        print("valid format")
        #iterating through all pages
        for page in tqdm(range(num_pages)[1:],desc="Processing pdf"): 
            claim_nos = []
            desc_res_list = []
            text = reader.getPage(page).extractText()
            search = False
            search = re.search("Policy\s*:|Policy\s*Number\s*:",text)
            if search:
                if re.search("Claim\s*#",text): 
                    # print(re.search("Claim\s*#",text)) 
                    # print(page)
                    policy = False
                    search_text = re.split("Policy\s*:\s*[A-Z]+|Policy\s*Number\s*:",text)[-1]
                    policy_pattern = False
                    policy_pattern = re.search("\d{10}-\d{3}-\d{3,4}|[A-Z]+\s*\d{10}\s*[A-Z]+",search_text)
                    # print(policy_pattern)
                    if policy_pattern:
                            # print(policy_pattern)
                            # print(page)
                            policy_pattern = re.search("\d{10}-\d{3}-\d{3,4}|\w+\s*\d{10}",search_text)
                            policy = re.split(policy_pattern.group(0),search_text)[0]
                            policy = policy + " " + policy_pattern.group(0)
                            policy = policy.strip()
                            dates = re.search("\d{2}/\d{2}/\d{4}\s*-\s*\d{2}/\d{2}/\d{4}",search_text).group(0)
                            effective_date = dates.split("-")[0].strip()
                            expiration_date = dates.split("-")[-1].strip()
                            a = datetime.strptime(effective_date, date_format)
                            b = datetime.strptime(expiration_date, date_format)
                            delta = b - a
                            policy_period = delta.days
                            claim_nos = re.findall("\d{3}-\d{6}-\d{3}", search_text) 
                            tables = camelot.read_pdf(file_name, pages=str(page+1),flavor='stream',edge_tol=500, row_tol=1,col_tol=1, split_text=True)
                            df = tables[0].df
                            # print(df)
                            row = df[df[0].str.contains("Claimant\s*Name")].index.values[0]
                            # print(row)

                            df = df.drop(df.index[[i for i in range(row)]])
                            df.reset_index(drop=True, inplace=True)
                            reserves = ""
                            recoveries = ""
                            incurred = ""
                            
                            if df[df[0].str.contains("Level\s*3\s*:|Policy\s*:")].shape[0] > 0:
                                end_row = df[df[0].str.contains("Level\s*\d\s*:|Policy\s*:")].index.values[0]
                                df_1 = df.iloc[:end_row,:]
                                # df = df.iloc[:end_row+1:]
                                try:
                                    reserves_row = df.iloc[2][df.iloc[2].str.contains("serves")].index.values[0]
                                    reserves = df[reserves_row].iloc[-1]
                                    if not reserves:
                                        if not df[reserves_row + 1].iloc[0]:
                                            reserves = df[reserves_row + 1].iloc[-1]
                                    try:
                                        reserves = reserves.split("\n")[-1]
                                    except:
                                        pass
                                except:
                                    pass

                                try:
                                    recoveries_row = df.iloc[2][df.iloc[2].str.contains("coveries")].index.values[0]
                                    recoveries = df[recoveries_row].iloc[-1]
                                    if not recoveries:
                                        if not df[recoveries_row + 1].iloc[0]:
                                            recoveries = df[recoveries_row + 1].iloc[-1]
                                    try:
                                        recoveries = recoveries.split("\n")[-1]
                                    except:
                                        pass
                                except:
                                    pass

                                try:
                                    incurred_row = df.iloc[2][df.iloc[2].str.contains("curred")].index.values[0]
                                    incurred = df[incurred_row].iloc[-1]
                                    if not incurred:
                                        if not df[incurred_row + 1].iloc[0]:
                                            incurred = df[incurred_row + 1].iloc[-1]
                                    try:
                                        incurred = incurred.split("\n")[-1]
                                    except:
                                        pass
                                except:
                                    pass
                            else:
                                    df_1 = df    

                            for i in range(3):   #.index.values[0]
                                v = df_1.iloc[i][df_1.iloc[i].str.contains("Accident|Loss\s*Desc")]
                                if v.to_list():
                                    col = v.index.values[0]
                                    break

                            desc_list = [desc.split("\n")[-1] for desc in list(df_1[col])]
                            desc_res_list = list(divide_chunks(desc_list, 3))[1:]
                            desc_res_list = [" ".join(desc) for desc in desc_res_list]



                            result[page] = {"policy no":policy,"effective_date" : effective_date,"expiration_date":expiration_date,
                                                                        "policy_period":policy_period ,"claim_nos":claim_nos,"desc_res_list":desc_res_list,
                                                                        
                                                                        "total_reserves":reserves,"total_recoveries":recoveries,
                                                                        "total_incurred":incurred,
                                                                        # "df":df
                                                            }

                                
        print(result)
        res_df = pd.DataFrame(result).T
        recoveries_indexes = res_df.index[res_df['total_recoveries'] == ""].tolist()
        incurred_indexes = res_df.index[res_df['total_incurred'] == ""].tolist()
        reserves_indexes = res_df.index[res_df['total_reserves'] == ""].tolist()

        if recoveries_indexes == incurred_indexes == reserves_indexes:
            for i in recoveries_indexes:
                if len(res_df) > (i+1):
                        res_df['total_recoveries'][i] = res_df['total_recoveries'][i+1]
                        res_df['total_incurred'][i] = res_df['total_incurred'][i+1]
                        res_df['total_reserves'][i] = res_df['total_reserves'][i+1]

        for i in res_df['claim_nos'].index.to_list():
            if len(res_df['desc_res_list'][i]) != len(res_df['claim_nos'][i]):
                if re.search('Claim\s*Count',res_df['desc_res_list'][i][-1]):
                        res_df['desc_res_list'][i] = res_df['desc_res_list'][i][:-1]
                if res_df['desc_res_list'][i]:
                        if res_df['desc_res_list'][i][-1].strip().isdecimal():
                                res_df['desc_res_list'][i] = res_df['desc_res_list'][i][:-1]
                if len(res_df['desc_res_list'][i]) != len(res_df['claim_nos'][i]):
                    if re.search('No\s*Claims',res_df['desc_res_list'][i][-1]):
                        res_df['claim_nos'][i] = ["NO CLAIMS" for i in range(len(res_df['desc_res_list'][i]))]
                    else:
                        des_len = len(res_df['desc_res_list'][i])
                        claim_len = len(res_df['claim_nos'][i])
                        if des_len > claim_len:
                            res_df['claim_nos'][i] = res_df['claim_nos'][i] + ["no decs" for i in range(des_len-claim_len)]
                        else:
                            res_df['desc_res_list'][i] = res_df['desc_res_list'][i]+ ["no claims" for i in range(claim_len-des_len)]

        exploded_df = res_df.set_index(res_df.index).apply(pd.Series.explode)
        exploded_df.reset_index(inplace=True,drop=True)
        exploded_df.drop(['total_recoveries','total_incurred','total_reserves'],axis=1,inplace=True)
        res_df.drop(['desc_res_list'],axis=1,inplace=True)
        head, tail = os.path.split(file_name)
        excel_name = os.path.join(downloads_path, str(tail).split('.')[0] + '.xlsx')
        res_df.to_excel(excel_name,index=False)
        
        exploded_name = os.path.join(downloads_path,  str(tail).split('.')[0] + ' - exploded.xlsx')
        exploded_df.to_excel(exploded_name,index=False)
        blob_client = blob_service_client.get_blob_client(container=container_name, blob='downloads/' + str(tail).split('.')[0] + '.xlsx')
        with open(os.path.normpath(excel_name), "rb") as data:
            blob_client.upload_blob(data)	
        blob_client = blob_service_client.get_blob_client(container=container_name, blob='downloads/' + str(tail).split('.')[0] + ' - exploded.xlsx')
        with open(os.path.normpath(exploded_name), "rb") as data:
            blob_client.upload_blob(data)	
        try:
            os.remove(exploded_name)
            os.remove(excel_name)
        except:
            pass
        return("Files saved into blob storage in the Downloads folder as "+str(tail).split('.')[0] + '.xlsx and ' + str(tail).split('.')[0] + ' - exploded.xlsx')
    else:
        return("Invalid format")

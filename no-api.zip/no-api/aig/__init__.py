import logging
from urllib import response
import uuid
import azure.functions as func
from .aig import return_file
import os
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient   
import mimetypes
import tempfile


import azure.functions as func


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    filename = req.params.get('filename')
    if not filename:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            filename = req_body.get('filename')
    if filename:
        if 'pdf' in str(filename.split('.')[-1].strip()) and 'PDF' in str(filename.split('.')[-1].strip()):
            return func.HttpResponse(
                "File is not a pdf file",
                status_code=200
            )
        connect_str = 'DefaultEndpointsProtocol=https;AccountName=storageaccountrkh;AccountKey=/sLzibq+T90hF1+KNi4oR7kYWyk338HjIug69dKfgM6NFDeCkZpMzO4LsX5wvO5xjSbpBz6Nfc98XSTjqrcMMw==;EndpointSuffix=core.windows.net'
        tempFilePath = tempfile.gettempdir()
        upload_path = os.path.join(tempFilePath, 'uploads')
        try:
            blob = BlobClient.from_connection_string(conn_str=connect_str, container_name="pdf", blob_name="uploads/"+filename)
            if not os.path.exists(upload_path):
                os.makedirs(upload_path)
            with open(os.path.join(upload_path, filename), "wb") as my_blob:
                blob_data = blob.download_blob()
                blob_data.readinto(my_blob)
            res = return_file(os.path.join(upload_path, filename))
            os.remove(os.path.join(upload_path, filename))
            return func.HttpResponse(res)
        except:
            return func.HttpResponse(
                "File not found on blob storage",
                status_code=200
        )
        
        
        
    else:
        return func.HttpResponse(
             "This HTTP triggered function executed successfully. Pass a filename in the query string or in the request body for a personalized response.",
             status_code=200
        )
